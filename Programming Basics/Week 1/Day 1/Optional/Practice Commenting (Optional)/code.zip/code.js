// A variable that counts likes.
var likeCount = 0;
// Increases the like counter every time it's called.
function increaseLikes() {
    // increment the variable by 1.
    likeCount = likeCount + 1;
}
